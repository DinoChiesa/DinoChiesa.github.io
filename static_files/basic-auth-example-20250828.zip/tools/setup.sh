#!/bin/bash
# -*- mode:shell-script; coding:utf-8; sh-shell:bash -*-
# Copyright © 2025 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#


KVNAME=example-credentials
PROXY_NAME=basic-auth-decode
scriptdir="$(cd "$(dirname "BASH_SOURCE[0]")" >/dev/null 2>&1 && pwd)"

source ./_utils.sh

import_and_deploy() {
  local rev dirpath
  printf "Importing %s into %s...\n" "$PROXY_NAME" "${APIGEE_PROJECT_ID}"
  dirpath="$scriptdir/../apiproxy"
  rev=$(apigeecli apis create bundle -f "${dirpath}" -n "$PROXY_NAME" --org "$APIGEE_PROJECT_ID" --token "$TOKEN" --disable-check | jq ."revision" -r)
  printf "Deploying proxy %s revision %s into %s/%s...\n" "$PROXY_NAME" "$rev" "$APIGEE_PROJECT_ID" "$APIGEE_ENV"
  apigeecli apis deploy --wait --name "$PROXY_NAME" --ovr --rev "$rev" --org "$APIGEE_PROJECT_ID" --env "$APIGEE_ENV" --token "$TOKEN" --disable-check
}

maybe_setup_keyvalue_map() {
  local kvms found item username i random_pw
  kvms=($(apigeecli kvms list -o "$APIGEE_PROJECT_ID" --token "$TOKEN" | sed -E 's/[]",[]//g'))
  found=false
  for item in "${kvms[@]}"; do
    if [[ "$item" == "$KVNAME" ]]; then
      found=true
      break
    fi
  done
  if [[ "$found" == "true" ]]; then
    printf "Found existing KVM %s...\n" "$KVNAME"
  else
    printf "Creating KVM %s...\n" "$KVNAME"
    apigeecli kvms create --name "${KVNAME}" -o "$APIGEE_PROJECT_ID" --token "$TOKEN"
  fi

  # Maybe Create a few entries
  for ((i = 1; i <= 4; i++)); do
    username=$(printf "user%04d" "$i")
    if apigeecli kvms entries get --map credentials --key "$username" -o "$APIGEE_PROJECT_ID" --token "$TOKEN" >/dev/null 2>&1; then
      printf "Creating "
      random_pw=$(tr -dc 'abcdefghijklmnopqrstuvwxyz0123456789' </dev/urandom | head -c 12)
      apigeecli kvms entries create --map "$KVNAME" --key "$username" --value "$random_pw" \
        -o "$APIGEE_PROJECT_ID" --token "$TOKEN" >/dev/null 2>&1
    else
      printf "Found "
    fi
    random_pw=$(apigeecli kvms entries get --map "$KVNAME" --key "$username" \
      -o "$APIGEE_PROJECT_ID" --token "$TOKEN" | jq .value -r)
    printf "user credential %s:%s\n" "$username" "$random_pw"
  done
}

# ====================================================================

check_shell_variables APIGEE_PROJECT_ID APIGEE_ENV
check_required_commands apigeecli jq gcloud tr sed grep

TOKEN=$(gcloud auth print-access-token)
maybe_setup_keyvalue_map
import_and_deploy
