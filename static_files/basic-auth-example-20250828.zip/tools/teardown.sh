#!/bin/bash
# -*- mode:shell-script; coding:utf-8; sh-shell:bash -*-
# Copyright © 2025 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

KVNAME=example-credentials
PROXY_NAME=basic-auth-decode
scriptdir="$( cd "$( dirname "BASH_SOURCE[0]" )" >/dev/null 2>&1 && pwd )"

source ./_utils.sh

delete_apiproxy() {
  local proxy_name TMPFILE ENVNAME REV NUM_DEPLOYS
  proxy_name="$PROXY_NAME"
  printf "Checking Proxy %s\n" "${proxy_name}"
  printf "apigeecli apis get --name \"$proxy_name\" --org \"$APIGEE_PROJECT_ID\" --token \"****\" --disable-check\n"
  if apigeecli apis get --name "$proxy_name" --org "$APIGEE_PROJECT_ID" --token "$TOKEN" --disable-check >/dev/null 2>&1; then
    TMPFILE=$(mktemp /tmp/apigee-samples.apigeecli.out.XXXXXX)
    printf "apigeecli apis listdeploy --name \"$proxy_name\" --org \"$APIGEE_PROJECT_ID\" --token \"****\" --disable-check\n"
    if apigeecli apis listdeploy --name "$proxy_name" --org "$APIGEE_PROJECT_ID" --token "$TOKEN" --disable-check >"$TMPFILE" 2>&1; then
      NUM_DEPLOYS=$(jq -r '.deployments | length' "$TMPFILE")
      if [[ $NUM_DEPLOYS -ne 0 ]]; then
        echo "Undeploying ${proxy_name}"
        for ((i = 0; i < NUM_DEPLOYS; i++)); do
          ENVNAME=$(jq -r ".deployments[$i].environment" "$TMPFILE")
          REV=$(jq -r ".deployments[$i].revision" "$TMPFILE")

          printf "apigeecli apis undeploy --name \"${proxy_name}\" --env \"$ENVNAME\" --rev \"$REV\" --org \"$APIGEE_PROJECT_ID\" --token \"****\" --safeundeploy=false --disable-check\n"
          apigeecli apis undeploy --name "${proxy_name}" --env "$ENVNAME" --rev "$REV" --org "$APIGEE_PROJECT_ID" --token "$TOKEN" --safeundeploy=false --disable-check
        done
      else
        printf "  There are no deployments of %s to remove.\n" "${proxy_name}"
      fi
    fi
    [[ -f "$TMPFILE" ]] && rm "$TMPFILE"

    echo "Deleting proxy ${proxy_name}"
    printf "apigeecli apis delete --name \"${proxy_name}\" --org \"$APIGEE_PROJECT_ID\" --token \"****\" --disable-check\n"
    apigeecli apis delete --name "${proxy_name}" --org "$APIGEE_PROJECT_ID" --token "$TOKEN" --disable-check
    printf "Deleted.\n"
  else
    printf "The proxy %s does not exist.\n" "${proxy_name}"
  fi
}

remove_keyvalue_map() {
  local kvms found item username i random_pw
  kvms=($(apigeecli kvms list -o "$APIGEE_PROJECT_ID" --token "$TOKEN" | sed -E 's/[]",[]//g'))
  found=false
  for item in "${kvms[@]}"; do
    if [[ "$item" == "$KVNAME" ]]; then
      found=true
      break
    fi
  done
  if [[ "$found" == "true" ]]; then
    printf "Found existing KVM %s...\n" "$KVNAME"
    apigeecli kvms delete --name "${KVNAME}" -o "$APIGEE_PROJECT_ID" --token "$TOKEN"
    printf "Deleted.\n"
  else
    printf "The KVM %s does not exist.\n" "$KVNAME"
  fi
}

# ====================================================================

check_shell_variables APIGEE_PROJECT_ID APIGEE_ENV
check_required_commands apigeecli jq gcloud tr sed grep head

TOKEN=$(gcloud auth print-access-token)
delete_apiproxy
remove_keyvalue_map

