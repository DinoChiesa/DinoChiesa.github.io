# Summary

This is a sample API Proxy that demonstrates how to use the
BasicAuthentication policy in Apigee X.

https://discuss.google.dev/t/how-to-do-basic-authentication-in-apigee-x/258454/8

## Disclaimer

This example is not an official Google product, nor is it part of an
official Google product.


## Pre-requisites for Using the sample

- a linux shell
- gcloud
- apigeecli
- An Apigee X organization/project
- a bunch of other linux utilities
- optional: curl

## Setup

0. unpack the zip

1. open a terminal window

2. cd tools

3. Set your environment
   ```sh
   export APIGEE_PROJECT_ID=your-project-id-398392
   export APIGEE_ENV=your-env
   ```

4. Run the setup script
   ```sh
   ./setup.sh
   ```

   The script creates an api proxy called `basic-auth-decode`.
   As well as an organization-scoped KVM called `example-credentials`. In
   this example, the KVM is scoped to the Apigee project; it is also possible to
   create KVMs scope to the Environment, or to the proxy.  This example does not
   cover that.

   The script will emit a set of username / password pairs.  For each one, it
   will create an entry in the Key-Value Map. You will need one or more of those
   later.

5. invoke the proxy

   Use one of the username/password pairs emitted by the script in
   the step above.  You can  use any REST client, like Postman, etc. If you use curl,
   you can specify the username/password on the command line with the `-u`
   switch.

   example:
   ```sh
   apigee=https://my-apigee-ingress-hostname.net
   curl -u user0001:o309jdkjwl2 $apigee/basic-auth-decode
   ```

## Teardown

1. open a terminal window

2. cd tools

3. Set your environment
   ```sh
   export APIGEE_PROJECT_ID=your-project-id-398392
   export APIGEE_ENV=your-env
   ```

4. Run the teardown script
   ```sh
   ./teardown.sh
   ```

## Support

This example is open-source software, and is not a supported part of Apigee.  If
you need assistance, you can try inquiring on [the Google Cloud Community forum
dedicated to Apigee](https://goo.gle/apigee-community) There is no service-level
guarantee for responses to inquiries posted to that site.



